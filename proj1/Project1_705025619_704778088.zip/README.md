# Team Members
* Yutong Han, 705025619
* Ziye Xing, 704778088

# Dependencies
* matplotlib
* numpy
* sklearn
* nltk

# Usage
To run a task, simply use
```
$ python newsgroup.py [task index]
```
The index of task ranges from a to j